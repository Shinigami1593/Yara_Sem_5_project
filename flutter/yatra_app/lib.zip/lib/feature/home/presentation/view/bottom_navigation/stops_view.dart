import 'package:flutter/material.dart';

class StopsView extends StatefulWidget {
  const StopsView({super.key});

  @override
  State<StopsView> createState() => _StopsViewState();
}

class _StopsViewState extends State<StopsView> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text('BUS STOPS PAGES'));
  }
}