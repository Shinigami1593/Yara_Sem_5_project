// lib/features/profile/presentation/bloc/profile_state.dart

import 'package:equatable/equatable.dart';
import 'package:yatra_app/feature/auth/domain/entity/user_entity.dart';

class ProfileState extends Equatable {
  final bool isLoading;
  final bool isSuccess;
  final UserEntity? user;
  final String? errorMessage;

  const ProfileState({
    required this.isLoading,
    required this.isSuccess,
    this.user,
    this.errorMessage,
  });

  // Initial state when the feature is first loaded
  factory ProfileState.initial() {
    return const ProfileState(
      isLoading: false,
      isSuccess: false,
      user: null,
      errorMessage: null,
    );
  }

  // Helper method to create a copy of the state with new values
  ProfileState copyWith({
    bool? isLoading,
    bool? isSuccess,
    UserEntity? user,
    String? errorMessage,
  }) {
    return ProfileState(
      isLoading: isLoading ?? this.isLoading,
      isSuccess: isSuccess ?? this.isSuccess,
      user: user ?? this.user,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  List<Object?> get props => [isLoading, isSuccess, user, errorMessage];
}