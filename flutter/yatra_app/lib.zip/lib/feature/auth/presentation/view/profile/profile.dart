import 'package:flutter/material.dart';

class ProfileView extends StatefulWidget {
  const ProfileView({super.key});

  @override
  State<ProfileView> createState() => _ProfileViewState();
}

class _ProfileViewState extends State<ProfileView> {
  @override
Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: Colors.white,
    appBar: AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      title: Text(
        'Profile',
        style: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
      ),
      centerTitle: true,
      iconTheme: IconThemeData(color: Colors.black),
    ),
    body: SingleChildScrollView(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      child: Column(
        children: [
          SizedBox(height: 20),
          CircleAvatar(
            radius: 45,
            backgroundImage: AssetImage('assets/avatar.png'),
          ),
          SizedBox(height: 15),
          Text('Rajesh Lama',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
          Text('rajesh@email.com',
              style: TextStyle(color: Colors.grey[600], fontSize: 14)),
          Divider(height: 40),

          _buildSettingTile(
              icon: Icons.language,
              title: "Language",
              trailing: DropdownButton<String>(
                value: 'EN',
                onChanged: (val) {},
                underline: SizedBox(),
                items: ['EN', 'NP'].map((lang) {
                  return DropdownMenuItem(
                      value: lang,
                      child: Text(lang, style: TextStyle(fontSize: 14)));
                }).toList(),
              )),

          _buildSettingSwitchTile(
              icon: Icons.dark_mode,
              title: "Dark Theme",
              value: isDarkMode,
              onChanged: (val) => setState(() => isDarkMode = val)),

          _buildSettingSwitchTile(
              icon: Icons.fingerprint,
              title: "Fingerprint Login",
              value: isFingerprintEnabled,
              onChanged: (val) => setState(() => isFingerprintEnabled = val)),

          SizedBox(height: 40),

          ElevatedButton.icon(
            icon: Icon(Icons.logout, color: Colors.white),
            label: Text("Logout", style: TextStyle(color: Colors.white)),
            onPressed: () {
              // Logout logic
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green.shade700,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
            ),
          ),
        ],
      ),
    ),
  );
}

// Reusable UI parts
Widget _buildSettingTile(
    {required IconData icon,
    required String title,
    required Widget trailing}) {
  return ListTile(
    leading: Icon(icon, color: Colors.green.shade700),
    title: Text(title),
    trailing: trailing,
  );
}

Widget _buildSettingSwitchTile(
    {required IconData icon,
    required String title,
    required bool value,
    required Function(bool) onChanged}) {
  return SwitchListTile(
    secondary: Icon(icon, color: Colors.green.shade700),
    title: Text(title),
    value: value,
    onChanged: onChanged,
    contentPadding: EdgeInsets.zero,
  );
}

}