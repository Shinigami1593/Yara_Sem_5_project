// lib/feature/auth/domain/use_case/update_profile_usecase.dart

import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
// 1. Import TokenSharedPrefs
import 'package:yatra_app/app/shared_pref/token_shared_pref.dart';
import 'package:yatra_app/app/use_case/use_case.dart';
import 'package:yatra_app/core/error/failure.dart';
import 'package:yatra_app/feature/auth/domain/entity/user_entity.dart';
import 'package.yatra_app/feature/auth/domain/entity/user_entity.dart';
import 'package:yatra_app/feature/auth/domain/repository/user_repository.dart';

class UpdateProfileParams extends Equatable {
  final String name;
  final String firstName;
  final String lastName;
  final String? profilePicture;

  const UpdateProfileParams({
    required this.name,
    required this.firstName,
    required this.lastName,
    this.profilePicture,
  });

  @override
  List<Object?> get props => [name, firstName, lastName, profilePicture];
}

class UpdateProfileUseCase implements UsecaseWithParams<UserEntity, UpdateProfileParams> {
  final IUserRepository _repository;
  // 2. Add the TokenSharedPrefs field
  final TokenSharedPrefs _tokenSharedPrefs;

  // 3. Require both dependencies in the constructor
  UpdateProfileUseCase({
    required IUserRepository repository,
    required TokenSharedPrefs tokenSharedPrefs,
  })  : _repository = repository,
        _tokenSharedPrefs = tokenSharedPrefs;

  @override
  Future<Either<Failure, void>> call(UpdateProfileParams params) async {
    // 4. Get the token before calling the repository
    final token = await _tokenSharedPrefs.getToken();

    // 5. Pass the token to the repository method
    return await _repository.updateProfile(
      params.name,
      params.firstName,
      params.lastName,
      params.profilePicture
    );
  }
}